import java.io.IOException;
import java.net.URL;

public class Run {
	public static void main(String[] args) throws IOException{
		GUI g = new GUI();
		}
	}
