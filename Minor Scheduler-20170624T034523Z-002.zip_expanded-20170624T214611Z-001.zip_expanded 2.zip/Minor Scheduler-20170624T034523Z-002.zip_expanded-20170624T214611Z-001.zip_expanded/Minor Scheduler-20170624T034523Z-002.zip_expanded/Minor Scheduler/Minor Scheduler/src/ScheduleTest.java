import static org.junit.Assert.*;

import java.io.File;

import org.junit.Test;

public class ScheduleTest {

	@Test
	public void test() {
		GUI g = new GUI();
		File f = new File("\\Users\\bavritzer\\Downloads\\Schedule.pdf");
		GUI.alph = f.toPath();
		for(String i : Major.types){
			for(String j : Minor.types){
				Schedule s = new Schedule(i, j, "Variety (recommended)", 8);
				s.detClass(s.major.reqs, s.minor.requirements,  s.minor.reqType);
				s.writePDF();
			}
		}
	}

}
