import static org.junit.Assert.*;
import java.io.IOException;
import java.util.ArrayList;

import org.junit.Test;

public class MajorTest {

	@Test
	public void testRead() throws IOException{
		Major m = new Major("Mechanical Engineering");
		assert(m.getRequirement(m) == new ArrayList<String>());
	}
}
