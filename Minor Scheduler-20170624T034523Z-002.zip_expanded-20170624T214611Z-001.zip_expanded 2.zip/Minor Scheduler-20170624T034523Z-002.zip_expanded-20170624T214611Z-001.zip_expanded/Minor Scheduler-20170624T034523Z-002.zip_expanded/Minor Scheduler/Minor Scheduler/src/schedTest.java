import static org.junit.Assert.*;

import org.junit.Test;

public class schedTest {
	
	@Test
	public void test1(){
		sched s = new sched("AEP 4230");
		System.out.println(s.name);
		System.out.println(s.time);
//		String q = s.purify(s.rawdata.substring(s.rawdata.indexOf("Prerequisite")));
//		String[] k = q.split(", ");
//		for(String i : k){
//			System.out.println("i: " + i);
//		}
		System.out.println(s.rawdata.substring(100, 500));
		System.out.println(s.title);
		System.out.println(s.getDescendants(s));
		for(String i : s.offered){
			System.out.println("dt: "+i);
		}
		for(int i : s.semOff){
			System.out.println(i+"##");
		}
		for(sched f : s.Prereq){
			System.out.println(f.name);
		}
		System.out.println("Prerequisite:".length());
		assert(s.isTE || s.courseNum==1910);
	}

}
